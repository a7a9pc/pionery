# Ahsan I. - Personal Portfolio Website

A modern, dark-themed personal portfolio website showcasing business development expertise and professional services.

## 🚀 Features

- **Modern Dark Theme**: Professional dark design with gradient accents and glass effects
- **Fully Responsive**: Optimized for desktop, tablet, and mobile devices
- **Interactive Contact Form**: Functional contact form with validation and API integration
- **Smooth Animations**: CSS animations and hover effects for enhanced user experience
- **Professional Sections**:
  - Hero section with professional introduction
  - About section highlighting expertise and competencies
  - Services section showcasing business development skills
  - Portfolio section with project highlights
  - Testimonials section with client feedback
  - Contact form with real-time validation

## 🛠️ Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and optimized builds
- **Tailwind CSS** for styling with custom CSS variables
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management
- **Radix UI** components with shadcn/ui
- **React Hook Form** with Zod validation
- **Lucide React** for icons

### Backend
- **Node.js** with Express.js
- **TypeScript** with ES modules
- **Zod** for request validation
- **Drizzle ORM** ready for PostgreSQL integration

## 📦 Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd portfolio-website
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 🏗️ Project Structure

```
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # Reusable React components
│   │   ├── pages/       # Route components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utilities and configurations
├── server/              # Express backend
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API route definitions
│   ├── storage.ts       # Data storage interfaces
│   └── vite.ts          # Vite integration
├── shared/              # Shared code between client and server
│   └── schema.ts        # Database schema definitions
└── components.json      # shadcn/ui configuration
```

## 🎨 Design Features

- **Dark Theme**: Professional dark color scheme with custom CSS variables
- **Glass Effects**: Modern glass morphism effects for UI elements
- **Gradient Accents**: Beautiful gradient colors for highlights and buttons
- **Responsive Design**: Mobile-first approach with breakpoint optimization
- **Smooth Animations**: CSS keyframe animations for enhanced UX

## 📧 Contact Form

The contact form includes:
- Real-time validation using Zod schemas
- Professional form styling with focus states
- Success/error toast notifications
- API endpoint for form submission handling

## 🚀 Deployment

The project is configured for easy deployment on platforms like:
- Replit
- Vercel
- Netlify
- Railway
- Any Node.js hosting platform

## 📱 Responsive Breakpoints

- Mobile: 320px - 768px
- Tablet: 768px - 1024px
- Desktop: 1024px+

## 🌟 Key Highlights

- **Business Development Focus**: Tailored content for business development professionals
- **Professional Branding**: Clean, modern design that conveys expertise
- **Client-Centered**: Content and design focused on client needs and results
- **Performance Optimized**: Fast loading times with optimized assets
- **SEO Ready**: Semantic HTML structure for better search engine visibility

## 📄 License

This project is licensed under the MIT License.

## 👨‍💼 About

This portfolio website was created for Ahsan I., a Business Development Manager based in Islamabad, Pakistan, specializing in strategic planning, partnership development, market analysis, and revenue growth.

---

Built with ❤️ using modern web technologies for optimal performance and user experience.