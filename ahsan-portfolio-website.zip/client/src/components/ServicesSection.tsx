import { Briefcase, Search, Handshake, BarChart2, Globe, Settings } from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      icon: Briefcase,
      title: "Business Strategy",
      description: "Develop comprehensive business strategies that align with your company's vision and market opportunities.",
      gradient: "from-[var(--dark-accent)] to-green-400"
    },
    {
      icon: Search,
      title: "Market Research",
      description: "In-depth market analysis to identify trends, opportunities, and competitive advantages in your industry.",
      gradient: "from-blue-500 to-blue-400"
    },
    {
      icon: Handshake,
      title: "Partnership Development",
      description: "Build strategic partnerships and alliances that drive mutual growth and market expansion.",
      gradient: "from-purple-500 to-purple-400"
    },
    {
      icon: BarChart2,
      title: "Sales Strategy",
      description: "Design and implement effective sales strategies that maximize revenue and customer acquisition.",
      gradient: "from-orange-500 to-orange-400"
    },
    {
      icon: Globe,
      title: "Market Expansion",
      description: "Navigate international markets and develop expansion strategies for global business growth.",
      gradient: "from-red-500 to-red-400"
    },
    {
      icon: Settings,
      title: "Process Optimization",
      description: "Streamline business processes and implement efficient systems for improved productivity and ROI.",
      gradient: "from-green-500 to-green-400"
    }
  ];

  return (
    <section id="services" className="py-20 bg-[var(--dark-primary)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Skills & Services</h2>
          <p className="text-[var(--dark-muted)] text-lg max-w-2xl mx-auto">
            Comprehensive business development solutions tailored to your unique needs
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className="bg-[var(--dark-secondary)] p-8 rounded-xl hover:bg-opacity-80 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${service.gradient} rounded-full flex items-center justify-center mb-6`}>
                  <IconComponent className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-4">{service.title}</h3>
                <p className="text-[var(--dark-muted)] leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
