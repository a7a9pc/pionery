export default function Footer() {
  return (
    <footer className="bg-[var(--dark-primary)] py-8 border-t border-gray-700">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-[var(--dark-muted)]">
            © 2024 Ahsan I. - Business Development Manager. All rights reserved.
          </p>
          <p className="text-sm text-[var(--dark-muted)] mt-2">
            Built with passion for driving business growth
          </p>
        </div>
      </div>
    </footer>
  );
}
