import { ArrowRight } from "lucide-react";

export default function PortfolioSection() {
  const portfolioItems = [
    {
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      title: "Tech Startup Expansion",
      description: "Strategic market expansion and business development for technology companies.",
      tags: ["Strategy", "Expansion", "Growth"],
      result: "Market Growth"
    },
    {
      image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      title: "Strategic Partnership",
      description: "Partnership development and strategic alliance facilitation for business growth.",
      tags: ["Partnership", "Negotiation", "Alliance"],
      result: "Strategic Success"
    },
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      title: "Market Analysis Framework",
      description: "Comprehensive market research and analysis framework development.",
      tags: ["Research", "Analysis", "Framework"],
      result: "Market Insights"
    }
  ];

  const tagColors: Record<string, string> = {
    "Strategy": "bg-[var(--dark-accent)]",
    "Expansion": "bg-blue-500",
    "Growth": "bg-green-500",
    "Partnership": "bg-purple-500",
    "Negotiation": "bg-orange-500",
    "Alliance": "bg-red-500",
    "Research": "bg-blue-500",
    "Analysis": "bg-green-500",
    "Framework": "bg-yellow-500"
  };

  return (
    <section id="portfolio" className="py-20 bg-[var(--dark-secondary)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Portfolio Highlights</h2>
          <p className="text-[var(--dark-muted)] text-lg max-w-2xl mx-auto">
            A showcase of successful projects and business transformations
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <div
              key={index}
              className="bg-[var(--dark-primary)] rounded-xl overflow-hidden hover:transform hover:-translate-y-2 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-[var(--dark-muted)] mb-4">
                  {item.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {item.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className={`px-3 py-1 ${tagColors[tag] || 'bg-gray-500'} text-white text-sm rounded-full`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="text-[var(--dark-accent)] font-semibold">{item.result}</div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center bg-gradient-to-r from-[var(--dark-accent)] to-green-400 hover:from-green-400 hover:to-[var(--dark-accent)] text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105"
          >
            <ArrowRight className="w-5 h-5 mr-2" />
            View More Projects
          </a>
        </div>
      </div>
    </section>
  );
}
