import { Star } from "lucide-react";

export default function TestimonialsSection() {
  const testimonials = [
    {
      rating: 5,
      text: "Exceptional strategic insights and professional business development expertise. Results-oriented approach with clear communication.",
      author: "Professional Client",
      role: "Business Executive",
      initials: "PC",
      gradient: "from-[var(--dark-accent)] to-green-400"
    },
    {
      rating: 5,
      text: "Outstanding partnership development skills and market analysis capabilities. Highly effective business growth strategies.",
      author: "Industry Partner",
      role: "VP Business Development",
      initials: "IP",
      gradient: "from-blue-500 to-blue-400"
    },
    {
      rating: 5,
      text: "Comprehensive market research and strategic planning expertise. Professional approach with measurable business outcomes.",
      author: "Global Client",
      role: "Chief Operating Officer",
      initials: "GC",
      gradient: "from-purple-500 to-purple-400"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-[var(--dark-primary)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Client Testimonials</h2>
          <p className="text-[var(--dark-muted)] text-lg max-w-2xl mx-auto">
            Professional feedback and business development success stories
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-[var(--dark-secondary)] p-8 rounded-xl relative">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400 mb-2">
                  {Array.from({ length: testimonial.rating }).map((_, starIndex) => (
                    <Star key={starIndex} className="w-5 h-5 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-[var(--dark-muted)] mb-6 leading-relaxed">
                "{testimonial.text}"
              </p>
              <div className="flex items-center">
                <div className={`w-12 h-12 bg-gradient-to-br ${testimonial.gradient} rounded-full flex items-center justify-center mr-4`}>
                  <span className="text-white font-semibold">{testimonial.initials}</span>
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.author}</h4>
                  <p className="text-sm text-[var(--dark-muted)]">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
