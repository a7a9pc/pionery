import { TrendingUp, Users, Target, DollarSign } from "lucide-react";

export default function AboutSection() {
  const competencies = [
    {
      icon: TrendingUp,
      title: "Strategic Planning",
      description: "Long-term vision and roadmap development"
    },
    {
      icon: Users,
      title: "Partnership Development",
      description: "Building strategic alliances and collaborations"
    },
    {
      icon: Target,
      title: "Market Analysis",
      description: "Comprehensive market research and insights"
    },
    {
      icon: DollarSign,
      title: "Revenue Growth",
      description: "Driving sustainable revenue expansion"
    }
  ];

  return (
    <section id="about" className="py-20 bg-[var(--dark-secondary)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">About Me</h2>
          <p className="text-[var(--dark-muted)] text-lg max-w-2xl mx-auto">
            Passionate about driving business growth and creating lasting partnerships
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold mb-4 gradient-text">Professional Background</h3>
            <p className="text-[var(--dark-muted)] leading-relaxed">
              With extensive experience in business development and strategic planning, I specialize in 
              identifying growth opportunities, building strategic partnerships, and implementing scalable business solutions. 
              My expertise spans across multiple industries including technology, manufacturing, and service sectors.
            </p>
            <p className="text-[var(--dark-muted)] leading-relaxed">
              Based in Islamabad, Pakistan, I work with clients from around the globe, 
              helping them navigate complex market challenges and achieve sustainable growth. My approach combines 
              data-driven insights with creative problem-solving to deliver measurable results.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="text-center p-4 bg-[var(--dark-primary)] rounded-xl">
                <div className="text-3xl font-bold text-[var(--dark-accent)] mb-2">Years</div>
                <div className="text-sm text-[var(--dark-muted)]">Experience</div>
              </div>
              <div className="text-center p-4 bg-[var(--dark-primary)] rounded-xl">
                <div className="text-3xl font-bold text-[var(--dark-accent)] mb-2">Global</div>
                <div className="text-sm text-[var(--dark-muted)]">Reach</div>
              </div>
              <div className="text-center p-4 bg-[var(--dark-primary)] rounded-xl">
                <div className="text-3xl font-bold text-[var(--dark-accent)] mb-2">Growth</div>
                <div className="text-sm text-[var(--dark-muted)]">Focused</div>
              </div>
              <div className="text-center p-4 bg-[var(--dark-primary)] rounded-xl">
                <div className="text-3xl font-bold text-[var(--dark-accent)] mb-2">Results</div>
                <div className="text-sm text-[var(--dark-muted)]">Driven</div>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold mb-6 gradient-text">Core Competencies</h3>
            
            <div className="space-y-4">
              {competencies.map((competency, index) => {
                const IconComponent = competency.icon;
                return (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-[var(--dark-accent)] rounded-full flex items-center justify-center">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{competency.title}</h4>
                      <p className="text-sm text-[var(--dark-muted)]">{competency.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
