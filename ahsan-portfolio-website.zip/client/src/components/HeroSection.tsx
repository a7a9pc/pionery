import { User, ExternalLink } from "lucide-react";

export default function HeroSection() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden pt-16"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--dark-primary)] via-[var(--dark-secondary)] to-[var(--dark-primary)]"></div>
      
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-slide-up">
          <div className="w-32 h-32 sm:w-40 sm:h-40 mx-auto mb-8 rounded-full bg-gradient-to-br from-[var(--dark-accent)] to-green-400 flex items-center justify-center animate-float">
            <User className="w-16 h-16 sm:w-20 sm:h-20 text-white" />
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            <span className="gradient-text">Ahsan I.</span>
          </h1>
          
          <h2 className="text-xl sm:text-2xl lg:text-3xl text-[var(--dark-muted)] mb-6 font-light">
            Business Development Manager
          </h2>
          
          <p className="text-lg sm:text-xl text-[var(--dark-muted)] mb-8 max-w-3xl mx-auto leading-relaxed">
            Driving business growth through strategic partnerships, market expansion, and innovative solutions. 
            Based in Islamabad, Pakistan, I help companies scale their operations and achieve sustainable success.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#contact"
              className="bg-gradient-to-r from-[var(--dark-accent)] to-green-400 hover:from-green-400 hover:to-[var(--dark-accent)] text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Get In Touch
            </a>
            
            <a
              href="https://www.upwork.com/freelancers/~0161df60e1d5320090"
              target="_blank"
              rel="noopener noreferrer"
              className="border-2 border-[var(--dark-accent)] text-[var(--dark-accent)] hover:bg-[var(--dark-accent)] hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 flex items-center"
            >
              <ExternalLink className="w-5 h-5 mr-2" />
              Hire Me on Upwork
            </a>
          </div>
        </div>
      </div>
      
      {/* Floating elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-[var(--dark-accent)] rounded-full opacity-20 animate-float"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-green-400 rounded-full opacity-10 animate-float" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-blue-400 rounded-full opacity-15 animate-float" style={{animationDelay: '2s'}}></div>
    </section>
  );
}
